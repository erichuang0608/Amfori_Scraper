from flask import Flask, render_template, jsonify, request
from flask_socketio import SocketIO
import sys
import io
import threading
import logging
from amfori_scraper import AmforiScraper
from amfori_detail_scraper import AmforiDetailScraper

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'
socketio = SocketIO(app, cors_allowed_origins="*")

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class OutputRedirector:
    def __init__(self, socketio):
        self.socketio = socketio
        self.buffer = io.StringIO()

    def write(self, text):
        if text.strip():  # Only send non-empty messages
            logger.info(f"Emitting output: {text.strip()}")
            self.socketio.emit('output', {'data': text})
            self.buffer.write(text)

    def flush(self):
        pass

@app.route('/')
def index():
    return render_template('index.html')

def run_scraper(scraper_type, site_ids=None):
    logger.info(f"Starting {scraper_type} scraper")
    logger.info(f"Site IDs parameter: {site_ids}")
    
    # Redirect stdout to our custom output handler
    old_stdout = sys.stdout
    sys.stdout = OutputRedirector(socketio)
    
    try:
        if scraper_type == 'amfori':
            logger.info("Initializing AmforiScraper")
            scraper = AmforiScraper()
            scraper.scrape()
        else:
            logger.info("Initializing AmforiDetailScraper")
            scraper = AmforiDetailScraper()
            
            # Ensure we have a valid token before proceeding
            try:
                logger.info("Validating token...")
                scraper.ensure_valid_token()
                logger.info("Token validation successful")
            except Exception as e:
                error_msg = f"Token validation failed: {str(e)}"
                logger.error(error_msg)
                logger.error("Full stack trace:", exc_info=True)
                print(error_msg)
                socketio.emit('scraper_complete', {
                    'scraper': scraper_type,
                    'status': 'error',
                    'message': f'Error validating token: {str(e)}'
                })
                return

            if site_ids and isinstance(site_ids, str) and site_ids.strip():
                logger.info(f"Running detail scraper with site IDs: {site_ids}")
                # Split the site_ids string into a list
                site_ids_list = [id.strip() for id in site_ids.split(':') if id.strip()]
                logger.info(f"Processed site IDs list: {site_ids_list}")
                not_found_ids = scraper.scrape_by_site_ids(site_ids_list)
                if not_found_ids:
                    logger.warning(f"Some site IDs were not found: {not_found_ids}")
                    socketio.emit('scraper_complete', {
                        'scraper': scraper_type,
                        'status': 'warning',
                        'message': f'Detail scraper completed with warnings. Some site IDs were not found: {", ".join(not_found_ids)}'
                    })
                    return
            else:
                logger.info("No site IDs provided, running detail scraper for all confirmed records")
                try:
                    scraper.scrape()
                except Exception as e:
                    error_msg = f"Error in scrape method: {str(e)}"
                    logger.error(error_msg)
                    logger.error("Full stack trace:", exc_info=True)
                    raise
            
        # Send completion event
        logger.info(f"Scraper {scraper_type} completed successfully")
        socketio.emit('scraper_complete', {
            'scraper': scraper_type,
            'status': 'success',
            'message': f'{scraper_type.title()} scraper completed successfully!'
        })
        logger.info("Completion event sent")
    except Exception as e:
        error_msg = f"Error running scraper: {str(e)}"
        logger.error(error_msg)
        logger.error("Full stack trace:", exc_info=True)
        print(error_msg)
        # Send error event
        socketio.emit('scraper_complete', {
            'scraper': scraper_type,
            'status': 'error',
            'message': f'Error running {scraper_type} scraper: {str(e)}'
        })
        logger.info("Error event sent")
    finally:
        sys.stdout = old_stdout
        logger.info(f"Finished running {scraper_type} scraper")

@app.route('/run/<scraper_type>', methods=['POST'])
def run(scraper_type):
    logger.info(f"Received request to run {scraper_type} scraper")
    
    if scraper_type not in ['amfori', 'detail']:
        logger.error(f"Invalid scraper type: {scraper_type}")
        return jsonify({'error': 'Invalid scraper type'})
    
    # Get site IDs from request if provided
    site_ids = None
    if scraper_type == 'detail':
        data = request.get_json()
        logger.info(f"Received request data: {data}")
        if data and 'site_ids' in data and data['site_ids'] and data['site_ids'].strip():
            site_ids = data['site_ids']
            logger.info(f"Processing site IDs: {site_ids}")
    
    # Start scraper in a separate thread
    thread = threading.Thread(target=run_scraper, args=(scraper_type, site_ids))
    thread.start()
    
    return jsonify({'status': 'started', 'scraper': scraper_type})

if __name__ == '__main__':
    logger.info("Starting Flask application")
    socketio.run(app, debug=True) 