#!/bin/bash

# 检查 Python 版本
python3 --version
if [ $? -ne 0 ]; then
    echo "错误：未找到 Python3，请先安装 Python 3.8 或更高版本"
    exit 1
fi

# 检查是否已安装 Chrome
if ! command -v google-chrome &> /dev/null; then
    echo "警告：未找到 Chrome 浏览器，请访问 https://www.google.com/chrome/ 下载安装"
fi

# 检查是否已安装 ChromeDriver
if ! command -v chromedriver &> /dev/null; then
    echo "警告：未找到 ChromeDriver，请安装与 Chrome 浏览器版本匹配的 ChromeDriver"
    echo "在 macOS 上可以使用：brew install chromedriver"
    echo "或访问 https://sites.google.com/chromium.org/driver/ 下载"
fi

# 创建虚拟环境
echo "创建虚拟环境..."
python3 -m venv venv

# 激活虚拟环境
echo "激活虚拟环境..."
source venv/bin/activate

# 安装依赖
echo "安装依赖..."
pip install -r requirements.txt

# 检查 .env 文件
if [ ! -f .env ]; then
    echo "创建 .env 文件..."
    cp .env.example .env
    echo "请在 .env 文件中设置你的 Amfori 用户名和密码"
fi

echo "安装完成！"
echo "请按照以下步骤运行程序："
echo "1. 激活虚拟环境：source venv/bin/activate"
echo "2. 运行爬虫：python amfori_scraper.py"
echo "3. 运行 Web 界面：python app.py"
echo "4. 在浏览器中访问：http://localhost:5000" 