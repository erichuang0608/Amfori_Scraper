import os
import time
import traceback
from datetime import datetime
import pandas as pd
import requests
from dotenv import load_dotenv
import json
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from amfori_scraper import AmforiScraper

class AmforiDetailScraper:
    def __init__(self):
        self.base_url = "https://platform.amfori.org"
        self.excel_file = "amfori_detail_data.xlsx"
        self.backup_file = "amfori_detail_data_backup.xlsx"
        self.source_excel = "amfori_data.xlsx"
        self.session = requests.Session()
        self.driver = None
        self.token_file = "amfori_detail_token.json"
        
    def setup_driver(self):
        print("Setting up Chrome driver...")
        chrome_options = Options()
        # chrome_options.add_argument('--headless')  # Commented out to show browser
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--disable-dev-shm-usage')
        
        service = Service('/opt/homebrew/bin/chromedriver')
        self.driver = webdriver.Chrome(service=service, options=chrome_options)
        self.driver.implicitly_wait(10)
        
    def login_and_get_token(self):
        """Login and get token, save it to file"""
        print("Getting token from first program...")
        try:
            # Create instance of first scraper and get token
            first_scraper = AmforiScraper()
            first_scraper.setup_driver()
            first_scraper.login_and_get_token()
            
            # Get the JWT token from cookies
            jwt_token = None
            for cookie in first_scraper.driver.get_cookies():
                if cookie['name'] == 'JWT_SECURITY_TOKEN':
                    jwt_token = cookie['value']
                    break
            
            if not jwt_token:
                raise Exception("JWT token not found in cookies")
            
            # Save token to file
            token_data = {
                'token': jwt_token,
                'timestamp': datetime.now().isoformat()
            }
            with open(self.token_file, 'w') as f:
                json.dump(token_data, f)
            print("Token saved to file")
            
            # Set up session headers with the token
            self.session.headers.update({
                'Authorization': f'Bearer {jwt_token}',
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            })
            
            print("Token obtained and headers set successfully!")
            return True
            
        except Exception as e:
            print(f"Login failed: {str(e)}")
            raise
        finally:
            if first_scraper and first_scraper.driver:
                first_scraper.driver.quit()
                
    def validate_token(self):
        """Check if token exists and is valid"""
        try:
            if not os.path.exists(self.token_file):
                print("No token file found")
                return False
                
            with open(self.token_file, 'r') as f:
                token_data = json.load(f)
                
            # Check if token exists
            if 'token' not in token_data:
                print("No token found in token file")
                return False
                
            # Set up session headers with token
            self.session.headers.update({
                'Authorization': f"Bearer {token_data['token']}",
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            })
            
            # Try to make a test request
            test_url = f"{self.base_url}/v1/services/monitoring/monitoring-partner-plannings/to-confirm/search"
            response = self.session.get(test_url, params={'rows': 1})
            
            if response.status_code == 401:
                print("Token is invalid or expired")
                return False
                
            print("Token is valid")
            return True
            
        except Exception as e:
            print(f"Error validating token: {str(e)}")
            return False
            
    def ensure_valid_token(self):
        """Ensure we have a valid token, login if necessary"""
        if not self.validate_token():
            print("Token invalid or missing, logging in...")
            self.login_and_get_token()
        else:
            print("Using existing valid token")
            
    def get_urls_from_excel(self):
        print("Reading URLs from Excel file...")
        try:
            df = pd.read_excel(self.source_excel)
            # Filter records where Status_comparation is "已确认"
            confirmed_records = df[df['Status_comparation'] == "Confirmed"]
            urls = confirmed_records['To_Plan_Link'].tolist()
            print(f"Found {len(urls)} confirmed records to process")
            return urls
        except Exception as e:
            print(f"Error reading Excel file: {str(e)}")
            raise
            
    def get_data(self, url):
        print(f"Fetching data from URL: {url}")
        try:
            # Extract UUID from URL
            uuid = url.split('/')[-1]
            api_url = f"{self.base_url}/v1/services/monitoring/monitoring-partner-plannings/{uuid}"
            
            response = self.session.get(api_url)
            response.raise_for_status()
            
            # Get response text
            response_text = response.text.strip()
            
            # If response contains "Response Content:", extract the JSON part
            if "Response Content:" in response_text:
                response_text = response_text.split("Response Content:", 1)[1].strip()
            
            # Try to parse JSON response
            try:
                data = json.loads(response_text)
            except json.JSONDecodeError as e:
                print(f"Failed to parse response as JSON: {str(e)}")
                print(f"Response text: {response_text}")
                raise Exception(f"Failed to parse response as JSON: {str(e)}")
            
            # Check if response is a dictionary
            if not isinstance(data, dict):
                print(f"Unexpected response format: {type(data)}")
                print(f"Response content: {data}")
                raise Exception("Unexpected response format from API")
                
            return data
            
        except requests.exceptions.RequestException as e:
            print(f"Network error: {str(e)}")
            print(f"Response headers: {response.headers if 'response' in locals() else 'No response'}")
            print(f"Response content: {response.text if 'response' in locals() else 'No response'}")
            raise
        except json.JSONDecodeError as e:
            print(f"JSON parsing error: {str(e)}")
            print(f"Response content: {response.text}")
            raise
        except Exception as e:
            print(f"Error fetching data: {str(e)}")
            print(f"Response headers: {response.headers if 'response' in locals() else 'No response'}")
            print(f"Response content: {response.text if 'response' in locals() else 'No response'}")
            raise
            
    def extract_data(self, response_data):
        print("Extracting data from response...")
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        try:
            # Check if response_data is a string
            if isinstance(response_data, str):
                print(f"Received string response: {response_data}")
                raise Exception(f"API returned string response: {response_data}")
                
            # Check if response_data is a dictionary
            if not isinstance(response_data, dict):
                print(f"Unexpected response format: {type(response_data)}")
                print(f"Response content: {response_data}")
                raise Exception("Unexpected response format from API")
            
            # Extract data for requirement 3 data
            monitored_site = response_data.get('monitoredSite', {})
            contact_details = monitored_site.get('contactDetails', {})
            confirmed_time_window = response_data.get('confirmedTimeWindow', {})
            requestor = response_data.get('requestor', {})
            requestor_contact = requestor.get('contactDetails', {})
            
            # Format address as string
            address = response_data.get('monitoredSite', {}).get('address', {})
            address_str = f"{address.get('street', '')}, {address.get('city', '')}, {address.get('zip', '')}, {address.get('country', {})}"
            
            # Format unavailability days as string
            unavailability_days = response_data.get('unavailabilityDays', [])
            unavailability_days_str = ', '.join(str(day) for day in unavailability_days) if unavailability_days else ''
            
            req3_data = {
                'Scraped At': current_time,
                'Status': 'New',  # Default status for new records
                'Request Date': response_data.get('requestDate', ''),
                'Site amfori ID': monitored_site.get('siteAmforiId', ''),
                'Monitoring ID': response_data.get('monitoringId', ''),
                'Company Name(LegalName)': monitored_site.get('monitoredPartyLegalName', ''),
                'Site Name(Sitename)': monitored_site.get('name', ''),
                'Local Name(Localname)': monitored_site.get('localName', ''),
                'Contact Email': contact_details.get('emailAddress', ''),
                'Contact Phonenumber': contact_details.get('phoneNumber', ''),
                'address': address_str,
                'Audit Start window(confirmedTimeWindow-from)': confirmed_time_window.get('from', ''),
                'Audit To window(confirmedTimeWindow-to)': confirmed_time_window.get('to', ''),
                'Status1': '',
                'Audit Start date': '',
                'Audit End date': '',
                'Unavailability Days': unavailability_days_str,
                'Schedule#': '',
                'Job#': '',
                'BSCI MEMBER': requestor.get('legalName', ''),
                'BSCI Member phonenumber': requestor_contact.get('phoneNumber', ''),
                'BSCI Member emailAddress': requestor_contact.get('emailAddress', ''),
                'Audit Announcement': response_data.get('announcementType', ''),
                'Audit Methodology': response_data.get('monitoringActivityName', ''),
                'Audit type': response_data.get('monitoringType', ''),
                'CS': '',
                'Remark（平台来单or CS来单）': '',
                'Related Sales': '',
                'Created At': current_time,
                'Updated At': current_time
            }
            
            return req3_data
            
        except Exception as e:
            print(f"Error in extract_data: {str(e)}")
            print("Full stack trace:")
            traceback.print_exc()
            print("\nResponse data type:", type(response_data))
            print("Response data content:", response_data)
            raise
            
    def update_excel(self, req3_data):
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        try:
            # Check if Excel file exists
            if not os.path.exists(self.excel_file):
                print("No existing Excel file found, creating new one")
                existing_req3_df = pd.DataFrame()
            else:
                # Try to read existing Excel file
                try:
                    with pd.ExcelFile(self.excel_file) as xls:
                        existing_req3_df = pd.read_excel(xls, sheet_name='Requirement3 Data')
                    print(f"Found existing Excel file with {len(existing_req3_df)} req3 records")
                except ValueError as e:
                    print("Excel file exists but sheet not found, creating new sheet")
                    existing_req3_df = pd.DataFrame()
            
        except Exception as e:
            print(f"Error reading Excel file: {str(e)}")
            print("Creating new Excel file")
            existing_req3_df = pd.DataFrame()
            
        # Convert new data to DataFrame
        new_req3_df = pd.DataFrame([req3_data])
        
        # Update requirement 3 data sheet
        if existing_req3_df.empty:
            existing_req3_df = new_req3_df
        else:
            # Update existing records or add new ones
            for _, row in new_req3_df.iterrows():
                mask = existing_req3_df['Site amfori ID'] == row['Site amfori ID']
                if mask.any():
                    # Update existing record
                    for col in row.index:
                        if col not in ['Created At']:  # Don't update creation date
                            existing_req3_df.loc[mask, col] = row[col]
                    existing_req3_df.loc[mask, 'Status'] = 'Updated'
                    existing_req3_df.loc[mask, 'Updated At'] = current_time
                    existing_req3_df.loc[mask, 'Scraped At'] = current_time
                else:
                    # Add new record
                    existing_req3_df = pd.concat([existing_req3_df, pd.DataFrame([row])], ignore_index=True)
        
        # Reorder columns to put Scraped At and Status first
        columns = ['Scraped At', 'Status'] + [col for col in existing_req3_df.columns if col not in ['Scraped At', 'Status']]
        existing_req3_df = existing_req3_df[columns]
        
        # Save to Excel
        with pd.ExcelWriter(self.excel_file) as writer:
            existing_req3_df.to_excel(writer, sheet_name='Requirement3 Data', index=False)
            
        print(f"Updated Excel file with {len(existing_req3_df)} req3 records")
        print(f"Requirement3 Data Status counts: {existing_req3_df['Status'].value_counts().to_dict()}")
            
    def update_source_excel_status(self, processed_urls):
        print("Updating source Excel file status...")
        try:
            # Read the source Excel file
            df = pd.read_excel(self.source_excel)
            
            # Update Status_comparation for processed URLs
            for url in processed_urls:
                mask = df['To_Plan_Link'] == url
                df.loc[mask, 'Status_comparation'] = "Extracted"
            
            # Save the updated DataFrame back to Excel
            df.to_excel(self.source_excel, index=False)
            print(f"Updated status for {len(processed_urls)} records in source Excel file")
            
        except Exception as e:
            print(f"Error updating source Excel file: {str(e)}")
            raise
            
    def backup_data(self):
        print("Starting data backup...")
        try:
            current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            
            # Check if source file exists
            if not os.path.exists(self.excel_file):
                print("No source file found, skipping backup")
                return
                
            # Read source data
            source_df = pd.read_excel(self.excel_file, sheet_name='Requirement3 Data')
            
            # Add backup time column
            source_df['备份时间'] = current_time
            
            # Check if backup file exists
            if os.path.exists(self.backup_file):
                # Read existing backup data
                backup_df = pd.read_excel(self.backup_file, sheet_name='Requirement3 Data')
                
                # Append new data
                backup_df = pd.concat([backup_df, source_df], ignore_index=True)
                print(f"Appended {len(source_df)} records to backup file")
            else:
                # Create new backup file
                backup_df = source_df
                print(f"Created new backup file with {len(source_df)} records")
            
            # Save backup data
            with pd.ExcelWriter(self.backup_file) as writer:
                backup_df.to_excel(writer, sheet_name='Requirement3 Data', index=False)
            
            print(f"Backup completed successfully. Total records in backup: {len(backup_df)}")
            
        except Exception as e:
            print(f"Error during backup: {str(e)}")
            print("Full stack trace:")
            traceback.print_exc()
            raise

    def get_urls_by_site_ids(self, site_ids):
        """Get URLs from Excel file based on provided site IDs"""
        print("Reading URLs from Excel file for specific site IDs...")
        try:
            df = pd.read_excel(self.source_excel)
            urls = []
            not_found_ids = []
            
            for site_id in site_ids:
                # Find matching record
                matching_records = df[df['Site amfori ID'] == site_id]
                if not matching_records.empty:
                    url = matching_records.iloc[0]['To_Plan_Link']
                    urls.append(url)
                    print(f"Found URL for site ID: {site_id}")
                else:
                    not_found_ids.append(site_id)
                    print(f"Site ID not found: {site_id}")
            
            if not_found_ids:
                print(f"\nWarning: The following site IDs were not found: {', '.join(not_found_ids)}")
            
            return urls, not_found_ids
            
        except Exception as e:
            print(f"Error reading Excel file: {str(e)}")
            raise
            
    def scrape_by_site_ids(self, site_ids):
        """Scrape data for specific site IDs"""
        try:
            # Backup data before starting
            self.backup_data()
            
            # Ensure we have a valid token
            self.ensure_valid_token()
            
            # Get URLs for the specified site IDs
            urls, not_found_ids = self.get_urls_by_site_ids(site_ids)
            processed_urls = []  # Keep track of successfully processed URLs
            
            if not urls:
                print("No valid URLs found to process")
                return
            
            # Process each URL
            for url in urls:
                try:
                    print(f"\nProcessing URL: {url}")
                    response_data = self.get_data(url)
                    req3_data = self.extract_data(response_data)
                    self.update_excel(req3_data)
                    processed_urls.append(url)  # Add to processed list
                    print(f"Successfully processed URL: {url}")
                    time.sleep(1)  # Add delay between requests
                except Exception as e:
                    print(f"Error processing URL {url}: {str(e)}")
                    print("Full stack trace:")
                    traceback.print_exc()
                    continue
            
            # Update source Excel file with processed status
            if processed_urls:
                self.update_source_excel_status(processed_urls)
            
            print("Scraping completed successfully!")
            
            # Return not found IDs for reporting
            return not_found_ids
            
        except Exception as e:
            print(f"Error during scraping: {str(e)}")
            print("Full stack trace:")
            traceback.print_exc()
            raise
        finally:
            if self.driver:
                self.driver.quit()

    def scrape(self):
        """Scrape data for all confirmed records"""
        try:
            # Backup data before starting
            self.backup_data()
            
            # Ensure we have a valid token
            self.ensure_valid_token()
            
            # Get URLs for all confirmed records
            urls = self.get_urls_from_excel()
            processed_urls = []  # Keep track of successfully processed URLs
            
            if not urls:
                print("No confirmed records found to process")
                return
            
            # Initialize status counters
            status_counts = {
                'New': 0,
                'Update': 0,
                'Confirmed': 0
            }
            
            # Process each URL
            for url in urls:
                try:
                    print(f"\nProcessing URL: {url}")
                    response_data = self.get_data(url)
                    req3_data = self.extract_data(response_data)
                    
                    # Update status counts based on the data
                    status = req3_data.get('Status', '')
                    if status in status_counts:
                        status_counts[status] += 1
                    
                    self.update_excel(req3_data)
                    processed_urls.append(url)  # Add to processed list
                    print(f"Successfully processed URL: {url}")
                    time.sleep(1)  # Add delay between requests
                except Exception as e:
                    print(f"Error processing URL {url}: {str(e)}")
                    print("Full stack trace:")
                    traceback.print_exc()
                    continue
            
            # Print status statistics
            print("\nScraping Status Summary:")
            for status, count in status_counts.items():
                if count > 0:
                    print(f"{status}: {count}")
                    # Print example sites for each status
                    print(f"Extracted data for site: {req3_data.get('Company Name(LegalName)', 'Unknown Company')}")
            
            # Update source Excel file with processed status
            if processed_urls:
                self.update_source_excel_status(processed_urls)
            
            print("\nScraping completed successfully!")
            
        except Exception as e:
            print(f"Error during scraping: {str(e)}")
            print("Full stack trace:")
            traceback.print_exc()
            raise
        finally:
            if self.driver:
                self.driver.quit()

    def get_token(self):
        """Get token from token file"""
        try:
            if not os.path.exists(self.token_file):
                print("No token file found")
                return None
                
            with open(self.token_file, 'r') as f:
                token_data = json.load(f)
                
            # Check if token exists
            if 'token' not in token_data:
                print("No token found in token file")
                return None
                
            return token_data['token']
            
        except Exception as e:
            print(f"Error getting token: {str(e)}")
            return None

def main():
    scraper = AmforiDetailScraper()
    
    # Ask user for input
    print("\nPlease choose the scraping mode:")
    print("1. Normal mode (process all confirmed records)")
    print("2. Custom mode (process specific site IDs)")
    
    while True:
        try:
            mode = input("\nEnter mode (1 or 2): ").strip()
            if mode in ['1', '2']:
                break
            print("Invalid input. Please enter 1 or 2.")
        except KeyboardInterrupt:
            print("\nProgram terminated by user.")
            return
    
    if mode == '1':
        # Normal mode - process all confirmed records
        scraper.scrape()
    else:
        # Custom mode - process specific site IDs
        while True:
            try:
                site_ids_input = input("\nEnter site IDs (separated by ':'): ").strip()
                if not site_ids_input:
                    print("No input provided. Please try again.")
                    continue
                    
                # Split and clean site IDs
                site_ids = [id.strip() for id in site_ids_input.split(':') if id.strip()]
                if not site_ids:
                    print("No valid site IDs provided. Please try again.")
                    continue
                    
                break
            except KeyboardInterrupt:
                print("\nProgram terminated by user.")
                return
        
        # Process the specified site IDs
        not_found_ids = scraper.scrape_by_site_ids(site_ids)
        
        # Report results
        if not_found_ids:
            print(f"\nNote: The following site IDs were not found in the source Excel file:")
            for site_id in not_found_ids:
                print(f"- {site_id}")

if __name__ == "__main__":
    main() 