import os
import time
from datetime import datetime
import pandas as pd
import requests
from dotenv import load_dotenv
import json
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.keys import Keys
import traceback

class AmforiScraper:
    def __init__(self):
        self.base_url = "https://platform.amfori.org"
        self.sso_url = "https://sso.amfori.org"
        self.target_url = "https://platform.amfori.org/ui/monitoring/monitoring-partner-planning/ongoing"
        self.api_url = f"{self.base_url}/v1/services/monitoring/monitoring-partner-plannings/to-confirm/search"
        self.excel_file = "amfori_data.xlsx"
        self.session = requests.Session()
        self.token_file = "amfori_token.json"
        self.setup_driver()
        
    def setup_driver(self):
        print("Setting up Chrome driver...")
        options = webdriver.ChromeOptions()
        # options.add_argument('--headless')  # Comment out headless mode
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        options.add_argument('--disable-gpu')
        options.add_argument('--window-size=1920,1080')
        options.add_argument('--disable-blink-features=AutomationControlled')
        options.add_experimental_option('excludeSwitches', ['enable-automation'])
        options.add_experimental_option('useAutomationExtension', False)
        
        # ChromeDriver path from Homebrew
        chromedriver_path = '/opt/homebrew/bin/chromedriver'
        
        # Verify ChromeDriver exists
        if not os.path.exists(chromedriver_path):
            raise Exception(f"ChromeDriver not found at {chromedriver_path}. Please install it using: brew install chromedriver")
        
        try:
            print(f"Using ChromeDriver at: {chromedriver_path}")
            service = Service(executable_path=chromedriver_path)
            self.driver = webdriver.Chrome(service=service, options=options)
            print("ChromeDriver initialized successfully")
        except Exception as e:
            print(f"Error setting up Chrome driver: {str(e)}")
            print("Please make sure ChromeDriver is installed and matches your Chrome version")
            print("You can check Chrome version with: /Applications/Google\\ Chrome.app/Contents/MacOS/Google\\ Chrome --version")
            print("And install matching ChromeDriver with: brew install chromedriver")
            raise
            
        self.wait = WebDriverWait(self.driver, 30)
        print("WebDriverWait initialized with 30 second timeout")
        
    def login_and_get_token(self):
        """Login and get token, save it to file"""
        print("Logging in...")
        try:
            # Load credentials from .env file
            load_dotenv()
            username = os.getenv("AMFORI_USERNAME")
            password = os.getenv("AMFORI_PASSWORD")
            
            if not username or not password:
                raise ValueError("Please set AMFORI_USERNAME and AMFORI_PASSWORD in .env file")
            
            # Navigate to SSO login page
            print("Navigating to SSO login page...")
            login_url = f"{self.sso_url}/auth/realms/amfori/protocol/openid-connect/auth"
            params = {
                'client_id': 'sustainability-platform',
                'response_type': 'code',
                'scope': 'openid',
                'redirect_uri': self.target_url,
                'state': 'a28d7a40-cd22-4662-9c76-03d7ec5a52dd',
                'nonce': 'dc68a6eb-8948-43d2-822c-2be129ae83e6'
            }
            self.driver.get(f"{login_url}?{requests.compat.urlencode(params)}")
            
            # Wait for login form and enter credentials
            print("Waiting for login form...")
            username_field = self.wait.until(
                EC.presence_of_element_located((By.CSS_SELECTOR, "input.form-control[name='username']"))
            )
            password_field = self.wait.until(
                EC.presence_of_element_located((By.CSS_SELECTOR, "input.form-control[name='password']"))
            )
            
            print("Entering credentials...")
            username_field.clear()
            username_field.send_keys(username)
            password_field.clear()
            password_field.send_keys(password)
            
            # Click login button
            login_button = self.wait.until(
                EC.element_to_be_clickable((By.CSS_SELECTOR, "input.btn.btn-primary.btn-lg.w-100[name='login']"))
            )
            login_button.click()
            
            # Wait for redirect to complete
            print("Waiting for redirect...")
            self.wait.until(lambda driver: driver.current_url.startswith(self.target_url))
            
            # Wait a bit for the page to fully load
            time.sleep(5)
            
            # Get all cookies
            print("Getting cookies...")
            cookies = self.driver.get_cookies()
            print(f"Found {len(cookies)} cookies")
            
            # Try to find the JWT security token in cookies
            jwt_token = None
            for cookie in cookies:
                print(f"Cookie name: {cookie['name']}")
                if cookie['name'] == 'JWT_SECURITY_TOKEN':
                    jwt_token = cookie['value']
                    print("Found JWT_SECURITY_TOKEN in cookies!")
                    break
            
            if jwt_token:
                # Save token to file
                token_data = {
                    'token': jwt_token,
                    'timestamp': datetime.now().isoformat()
                }
                with open(self.token_file, 'w') as f:
                    json.dump(token_data, f)
                print("Token saved to file")
                
                # Set up session headers
                self.session.headers.update({
                    'Authorization': f"Bearer {jwt_token}",
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                })
                print("Session headers updated successfully")
            else:
                print("No JWT token found in cookies")
                print("Current URL:", self.driver.current_url)
                print("Page source preview:", self.driver.page_source[:500])
                raise Exception("Failed to obtain JWT token")
            
            print("Login successful!")
            return True
            
        except Exception as e:
            print(f"Login failed: {str(e)}")
            self.driver.save_screenshot("login_error.png")
            raise
            
    def validate_token(self):
        """Check if token exists and is valid"""
        try:
            if not os.path.exists(self.token_file):
                print("No token file found")
                return False
                
            with open(self.token_file, 'r') as f:
                token_data = json.load(f)
                
            # Check if token exists
            if 'token' not in token_data:
                print("No token found in token file")
                return False
                
            # Set up session headers with token
            self.session.headers.update({
                'Authorization': f"Bearer {token_data['token']}",
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            })
            
            # Try to make a test request
            test_url = f"{self.base_url}/v1/services/monitoring/monitoring-partner-plannings/to-confirm/search"
            response = self.session.get(test_url, params={'rows': 1})
            
            if response.status_code == 401:
                print("Token is invalid or expired")
                return False
                
            print("Token is valid")
            return True
            
        except Exception as e:
            print(f"Error validating token: {str(e)}")
            return False
            
    def ensure_valid_token(self):
        """Ensure we have a valid token, login if necessary"""
        if not self.validate_token():
            print("Token invalid or missing, logging in...")
            self.login_and_get_token()
        else:
            print("Using existing valid token")
            
    def get_data(self, start=0, rows=25):
        print(f"Fetching data from offset {start}...")
        
        params = {
            'childQuery': '',
            'parentQuery': '+(monitoredSite.address.country.en_GB:China) +(monitoringInitiative.en_GB:BSCI monitoringInitiative.en_GB:QMI)',
            'rows': rows,
            'sort': '',
            'sortOrder': '',
            'start': start
        }
        
        try:
            response = self.session.get(self.api_url, params=params)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            print(f"Error fetching data: {str(e)}")
            raise
            
    def extract_data(self, response_data):
        print("Extracting data from response...")
        data = []
        
        if 'results' in response_data:
            for doc in response_data['results']:
                # Convert timestamp to datetime
                request_date = datetime.fromtimestamp(doc.get('requestDate', 0) / 1000).strftime("%Y-%m-%d %H:%M:%S")
                state_date = datetime.fromtimestamp(doc.get('currentState', {}).get('stateDate', 0) / 1000).strftime("%Y-%m-%d %H:%M:%S")
                
                # Get UUID from the document
                uuid = doc.get('uuid', '')
                
                # Get current status
                current_status = doc.get('currentState', {}).get('Status_comparation', {}).get('en_GB', '')
                
                # Get address components
                address = doc.get('monitoredSite', {}).get('address', {})
                street = address.get('street', '')
                city = address.get('city', '')
                zip_code = address.get('zip', '')
                country = address.get('country', {}).get('en_GB', '')
                
                # Combine address components into a single string
                address_parts = [street, city, zip_code, country]
                address1 = ', '.join(part for part in address_parts if part)
                
                row_data = {
                    'Site amfori ID': doc.get('monitoredSite', {}).get('siteAmforiId', ''),
                    'Site Name': doc.get('monitoredSite', {}).get('name', ''),
                    'Local Name': doc.get('monitoredSite', {}).get('localName', ''),
                    'Address': {
                        'Street': street,
                        'City': city,
                        'Zip': zip_code,
                        'Country': country
                    },
                    'Address1': address1,
                    'Legal Name': doc.get('monitoredSite', {}).get('monitoredPartyLegalName', ''),
                    'Initiative': doc.get('monitoringInitiative', {}).get('en_GB', ''),
                    'Status': current_status,
                    'Monitoring ID': doc.get('monitoringId', ''),
                    'Monitoring Type': doc.get('monitoringType', {}).get('en_GB', ''),
                    'Announcement Type': doc.get('announcementType', {}).get('en_GB', ''),
                    'Requestor': doc.get('requestorLegalName', ''),
                    'Request Date': request_date,
                    'State Date': state_date,
                    'To_Plan_Link': f"{self.base_url}/v1/services/monitoring/monitoring-partner-plannings/{uuid}",
                    'to_confirm_link': f"{self.base_url}/ui/monitoring/monitoring-partner-planning/ongoing/{uuid}",
                    'Created At': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    'Updated At': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    'Scraped At': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                }
                data.append(row_data)
                
        return data
        
    def update_excel(self, new_data):
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        try:
            existing_df = pd.read_excel(self.excel_file)
        except FileNotFoundError:
            existing_df = pd.DataFrame()
            
        # Convert new data to DataFrame
        new_df = pd.DataFrame(new_data)
        
        if existing_df.empty:
            # If no existing data, save new data with "New" status
            new_df['Status_comparation'] = "New"
            new_df['Scraped At'] = current_time
            # Reorder columns to put Scraped At first
            cols = ['Scraped At'] + [col for col in new_df.columns if col != 'Scraped At']
            new_df = new_df[cols]
            new_df.to_excel(self.excel_file, index=False)
        else:
            # Create a copy of existing data
            updated_df = existing_df.copy()
            
            # Update existing records and add new ones
            for idx, row in new_df.iterrows():
                mask = updated_df['Site amfori ID'] == row['Site amfori ID']
                if mask.any():
                    # Update existing record
                    for col in row.index:
                        if col not in ['Created At']:  # Don't update creation date
                            # Convert empty string to None for numeric columns
                            if pd.api.types.is_numeric_dtype(updated_df[col]) and row[col] == '':
                                updated_df.loc[mask, col] = None
                            else:
                                updated_df.loc[mask, col] = row[col]
                    updated_df.loc[mask, 'Updated At'] = current_time
                    updated_df.loc[mask, 'Scraped At'] = current_time
                    updated_df.loc[mask, 'Status_comparation'] = "Update"
                else:
                    # Add new record
                    row['Status_comparation'] = "New"
                    row['Scraped At'] = current_time
                    # Convert empty string to None for numeric columns
                    for col in row.index:
                        if pd.api.types.is_numeric_dtype(updated_df[col]) and row[col] == '':
                            row[col] = None
                    updated_df = pd.concat([updated_df, pd.DataFrame([row])], ignore_index=True)
            
            # Mark remaining records as "Confirmed" and update their timestamps
            confirmed_mask = ~updated_df['Site amfori ID'].isin(new_df['Site amfori ID'])
            updated_df.loc[confirmed_mask, 'Status_comparation'] = "Confirmed"
            updated_df.loc[confirmed_mask, 'Updated At'] = current_time
            updated_df.loc[confirmed_mask, 'Scraped At'] = current_time
            
            # Reorder columns to put Scraped At first
            cols = ['Scraped At'] + [col for col in updated_df.columns if col != 'Scraped At']
            updated_df = updated_df[cols]
            updated_df.to_excel(self.excel_file, index=False)
            
    def scrape(self):
        try:
            # Ensure we have a valid token
            self.ensure_valid_token()
            
            start = 0
            rows = 25
            all_data = []
            
            # Initialize status counters and site lists
            status_data = {
                'New': {'count': 0, 'sites': []},
                'Update': {'count': 0, 'sites': []},
                'Confirmed': {'count': 0, 'sites': []}
            }
            
            while True:
                response_data = self.get_data(start, rows)
                data = self.extract_data(response_data)
                
                if not data:
                    break
                    
                all_data.extend(data)
                
                # Check if there are more results
                total = response_data.get('totalItems', 0)
                if start + rows >= total:
                    break
                    
                start += rows
                time.sleep(1)  # Add delay between requests
            
            # Update Excel with all data
            self.update_excel(all_data)
            
            # Count statuses from the updated Excel file
            df = pd.read_excel(self.excel_file)
            total_records = len(df)
            print(f"\nTotal records scraped: {total_records}")
            
            for status in status_data.keys():
                mask = df['Status_comparation'] == status
                if mask.any():
                    status_data[status]['count'] = mask.sum()
                    status_data[status]['sites'] = df[mask]['Site Name'].tolist()
            
            # Print status statistics in the desired format
            print("\nScraping Status Summary:")
            for status, data in status_data.items():
                if data['count'] > 0:
                    print(f"{status}： {data['count']}；")
                    for site in data['sites']:
                        print(f"  Extracted data for site: {site}")
            
            print("\nScraping completed successfully!")
            
        except Exception as e:
            print(f"Error during scraping: {str(e)}")
            print("Full stack trace:")
            traceback.print_exc()
            raise
        finally:
            if self.driver:
                self.driver.quit()

if __name__ == "__main__":
    scraper = AmforiScraper()
    scraper.scrape() 